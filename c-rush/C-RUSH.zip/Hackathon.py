import sys
import xlwt
import datetime
import xlrd
from xlutils.copy import copy

date=datetime.datetime.now()
dt=int(date.strftime("%d"))
mn=int(date.strftime("%m"))

loc=("C:\\Users\ShriAman\Desktop\Hackathon.xls")
wb=xlrd.open_workbook(loc)
wk=copy(wb)
try:
    s=wk.add_sheet("Sheet "+str(dt)+" "+str(mn))
except:
    print("Worksheet already created")
    exit
    
res=len(wb.sheet_names())

s.write(0,0,"Date:")
s.write(1,0,"Expenses")
s.write(1,1,"To-Do List")
s.write(1,2,"Assignment")
s.write(1,3,"Due-Date")
s.write(1,4,"Deadline")

s.write(0,1,str(dt)+" "+str(mn))
x=int(input("Enter number of entries in expenses"))
for i in range(0,x):
    s.write(i+2,0,input("Enter "))

x=int(input("Enter number of entries in to-do list"))
for i in range(0,x):
    s.write(i+2,1,input("Enter "))
    
x=int(input("Enter number of entries in Assignments"))
for i in range(0,x):
    j=i+2
    s.write(j,2,input("Enter Assignment "))
    dd=list(map(int,input("Enter due-date in dd mm format").split()))
    st=str(dd[0])+" "+str(dd[1])
    s.write(j,3,st)
    
    if(mn==dd[1]):
        if(dt<dd[0]):
            dl=str(dd[0]-dt)+" days left"
        else:
            dl="Deadline ended"
    
    elif(mn<dd[1]):
        if(dt<=dd[0]):
            dl=str(dd[1]-mn)+"months "+str(dd[0]-dt)+"days left"
        else:
            dl="less than "+str(dd[1]-mn)+" month left"
    else:
        dl="Deadline ended"
        
    s.write(j,4,dl)
j=x+2
    
for i in range(0,res):
    sheet=wb.sheet_by_index(i)
    k=2
    try:
        while(sheet.cell_value(k,4)!=""):
            if(sheet.cell_value(k,4)!="Deadline ended"):
                ndd=list(map(int,sheet.cell_value(k,3).split()))
              
                if(mn==ndd[1]):
                    if(dt<ndd[0]):
                        dl=str(ndd[0]-dt)+" days left"
                    else:
                        dl="Deadline ended"
    
                elif(mn<ndd[1]):
                    if(dt<=ndd[0]):
                        dl=str(ndd[1]-mn)+"months "+str(ndd[0]-dt)+"days left"
                    else:
                        dl="less than "+str(ndd[1]-mn)+" month left"
                else:
                    dl="Deadline ended"
            s.write(j,4,dl)
            s.write(j,3,sheet.cell_value(k,3))
            s.write(j,2,sheet.cell_value(k,2))
            k=k+1
            j=j+1
    except:
        exit
        
        
wk.save(loc)   
